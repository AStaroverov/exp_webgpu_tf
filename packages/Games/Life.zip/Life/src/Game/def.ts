export const PLAYER_TEAM_ID = 0;
export const GAME_MAP_SIZE = 300;