export const MLState = {
    enabled: true,
    toggle: (enabled: boolean) => {
        MLState.enabled = enabled;
    },
};