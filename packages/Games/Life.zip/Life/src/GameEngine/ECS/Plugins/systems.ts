export enum SystemGroup {
    Before,
    After,
}